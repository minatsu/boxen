# Java Puppet Module for Boxen

Installs Java 7u40 for 64-bit Mac OSX and the Java Cryptography Extensions (JCE).

## Usage

```puppet
include java
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
